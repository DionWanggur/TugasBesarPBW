<footer>
        <div style="margin-bottom: 1%; margin-top: 2%; margin-left: 3%; margin-right: 2%;">
            <span style="border-right: 1px solid white;padding-right: 1%;">Jadwal Kuliah FTIS</span>
            <Span>Fakultas Teknik Informatika dan Sains - UNPAR</Span>
            <a href="help" style="float: right;"><i class="fa fa-question-circle" style="font-size:24px;color: black;"></i> <br> help</a>
        </div>
        <div style="margin-bottom: 1%;margin-left: 3%;">
            <span>Contact Us</span>
            <span class="contact"><a href="https://twitter.com/"><i class="fa fa-twitter" style="font-size:24px"></i></a></span>
            <span class="contact"><a href="https://www.instagram.com/"><i class="fa fa-instagram" style="font-size:24px"></i></a></span>
            <span class="contact"><a href="https://www.facebook.com/"><i class="fa fa-facebook-square" style="font-size:24px"></i></a></span>
        </div>
        <div style="margin-bottom: 2%;margin-left: 3%;">
            <a href="terms">Terms and Service</a>
        </div>
        <div>
            <p style="text-align:center; margin-bottom: 1%;"> Copyright &copy; 2020 Universitas Katolik Parahyangan. All Rights Reserved</p>
        </div>
</footer>