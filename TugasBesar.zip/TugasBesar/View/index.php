<div>
    <h1 style="text-align: center">JADWAL UJIAN FTIS</h1>
    <hr>
</div>
<div style="text-align: center">
    <img src="View/Img/ujian.jpg" alt="ujian">

    <form action="user" method="post" style="float:right">
        <label for="Username"><strong>Username</strong></label>
        <input type="text" id="Uname" name="firstname" placeholder="username" required>
        <label for="password"><strong>Password</strong> </label>
        <input type="password" id="Pass" name="lastname" placeholder="password" required>
        <input type="submit" value="Submit">
    </form>

    <p>
        <strong>
            Layanan bagi seluruh mahasiswa Fakultas Teknik Informatika dan Sains - UNPAR untuk melihat
            jadwal ujian yang akan dilaksanakan selama masa perkuliahan berlangsung.
        </strong>
    </p>
</div>